import "./styles/home.css";

function Home() {
    return(
        <div className='home'>
            <h1>Welcome to our Organic Store.</h1>
        </div>
    )
}

export default Home;