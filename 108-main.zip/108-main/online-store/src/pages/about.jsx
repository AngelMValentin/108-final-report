import './styles/about.css';

function About() {
    return (
        <div className='about'>
            <h1>Welcome to the About Page</h1>
        </div>
    )
}

export default About;