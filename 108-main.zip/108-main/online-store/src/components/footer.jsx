import './styles/footer.css';

function Footer() {
    return (
        <div className='footer'>
            <h1>Created by Angel</h1>
        </div>
    );
}

export default Footer;